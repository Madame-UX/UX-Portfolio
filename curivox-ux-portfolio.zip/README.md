# Curivox UX Research Portfolio

A responsive UX Research portfolio site built with React, Tailwind, and shadcn/ui.

## 🚀 Getting Started

### 1. Install dependencies
```bash
npm install
```

### 2. Run locally
```bash
npm run dev
```

### 3. Build for production
```bash
npm run build
```

### 4. Deploy on Vercel
- Go to [https://vercel.com](https://vercel.com)
- Import this repo
- Set `Framework = Vite`
- Deploy 🎉

### 5. Connect your domain
- In Vercel dashboard → Settings → Domains → Add `curivox.com`

## 📌 Features
- Fully responsive UX portfolio
- Project 1: AA Pilots Case Study
- Tailwind + shadcn/ui + lucide icons
- SEO-ready + optimized for recruiters
    