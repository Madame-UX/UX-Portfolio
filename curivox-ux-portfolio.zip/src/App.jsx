
import Portfolio from './pages/index.jsx';

export default function App() {
  return <Portfolio />;
}
